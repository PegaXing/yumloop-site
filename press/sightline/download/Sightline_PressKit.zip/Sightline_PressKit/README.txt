﻿SIGHTLINE: LOGIC PUZZLE - PRESS & CREATOR KIT
Every clue has a point of view.

Press page:     https://yumloop.net/press/sightline/
Steam:          https://store.steampowered.com/app/4509520
Game page:      https://yumloop.net/sightline_game/
Discord:        https://discord.gg/dsgBxhG3GP
Press contact:  Yoni, yoni@yumloop.net

STATUS
Coming soon to Steam (Windows, macOS, Steam Deck), iPhone & iPad, and Android. A free Steam demo is
coming soon. Wishlist on Steam to be notified at launch.

EARLY ACCESS
Journalists and content creators can request complimentary early access to the full game on Steam,
iPhone/iPad or Android, or on several platforms if you cover more than one. There is no embargo:
publish whenever you like. Request it on the press page or email yoni@yumloop.net.

CONTENTS
  01_Trailers            Gameplay trailer (1920x1080, 60 fps, 1:21) and 30 s vertical trailer (886x1920), originals
  02_Screenshots         14 gameplay screenshots, captured from the real game: campaign (early,
                         intermediate, advanced), Grand Levels, the Daily, Time Challenge, multiplayer
  03_Social-Clips        Five short gameplay clips (7-14 s, 1080p60) cut from the trailer
  04_Logos               Sightline lockup and wordmark (white, dark, blue); Yumloop logo (flat white/dark, and the
                         shaded 3D logo from the game launch screen, transparent and on blue), PNG
  05_App-Icons           1024 px app icons
  06_Key-Art_Store-Art   Key art (with and without logo, 4K) and Steam capsule art
  07_Text                Short and long descriptions, mechanics and features, factsheet, developer bio
  Sightline_Factsheet.pdf  One-page factsheet

ABOUT YUMLOOP
Yumloop is a new independent games studio founded by Yoni, a game designer who previously worked at
Rockstar North on Grand Theft Auto V, Red Dead Redemption 2 and Grand Theft Auto VI. Sightline is
Yumloop's first game, designed and built solo. It started with one question: what if a Minesweeper-
style clue didn't tell you what was immediately around it, but what it could see?

USAGE PERMISSIONS
Everything in this kit (trailers, clips, screenshots, logos, icons and key art) may be used freely
in editorial coverage, reviews, previews, videos and streams about Sightline, in print, online and
in video. Please don't alter the logos, or use the assets to suggest an endorsement or for unrelated
advertising. Monetised videos and streams of Sightline are welcome.

CREDITS
Trailer music: “Swing Has Swung” by Shane Ivers, https://www.silvermansound.com, licensed under CC
BY 4.0 (https://creativecommons.org/licenses/by/4.0/). If you re-upload a trailer or clip with its
audio, please keep this credit in the description. Crowd sounds: CC0 (Freesound). In-game music:
“Thinking & Tinkering” by Fablefly Music, CC BY 4.0.

© 2026 YUMLOOP GAMES LTD. All rights reserved. Sightline and the Sightline logo are trademarks of YUMLOOP GAMES LTD.
